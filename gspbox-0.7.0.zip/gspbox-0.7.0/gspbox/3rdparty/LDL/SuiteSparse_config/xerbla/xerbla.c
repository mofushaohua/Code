
void xerbla_ (char *srname, int *info)
{
    /* do nothing */ ;
}


void xerbla (char *srname, int *info)
{
    /* do nothing */ ;
}

